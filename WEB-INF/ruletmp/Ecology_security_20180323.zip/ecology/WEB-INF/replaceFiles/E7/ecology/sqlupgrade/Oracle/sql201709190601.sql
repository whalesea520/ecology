delete from HtmlLabelIndex where id=131596 
/
delete from HtmlLabelInfo where indexid=131596 
/
INSERT INTO HtmlLabelIndex values(131596,'���д�') 
/
INSERT INTO HtmlLabelInfo VALUES(131596,'���д�',7) 
/
INSERT INTO HtmlLabelInfo VALUES(131596,'Sensitive Word',8) 
/
INSERT INTO HtmlLabelInfo VALUES(131596,'���д�',9) 
/
delete from HtmlLabelIndex where id=131598 
/
delete from HtmlLabelInfo where indexid=131598 
/
INSERT INTO HtmlLabelIndex values(131598,'���д�������־') 
/
INSERT INTO HtmlLabelInfo VALUES(131598,'���д�������־',7) 
/
INSERT INTO HtmlLabelInfo VALUES(131598,'Sensitive Word Intercept Logs',8) 
/
INSERT INTO HtmlLabelInfo VALUES(131598,'�����~�r����־',9) 
/
delete from HtmlLabelIndex where id=131636 
/
delete from HtmlLabelInfo where indexid=131636 
/
INSERT INTO HtmlLabelIndex values(131636,'ֱ�ӹ��˲��Ҽ�¼��־') 
/
delete from HtmlLabelIndex where id=131637 
/
delete from HtmlLabelInfo where indexid=131637 
/
INSERT INTO HtmlLabelIndex values(131637,'����¼��־') 
/
INSERT INTO HtmlLabelInfo VALUES(131637,'����¼��־',7) 
/
INSERT INTO HtmlLabelInfo VALUES(131637,'Only Record Log',8) 
/
INSERT INTO HtmlLabelInfo VALUES(131637,'�Hӛ���־',9) 
/
INSERT INTO HtmlLabelInfo VALUES(131636,'ֱ�ӹ��˲��Ҽ�¼��־',7) 
/
INSERT INTO HtmlLabelInfo VALUES(131636,'Clean Sensitive Word And Record Log',8) 
/
INSERT INTO HtmlLabelInfo VALUES(131636,'ֱ���^�V����ӛ���־',9) 
/
delete from HtmlLabelIndex where id=131740 
/
delete from HtmlLabelInfo where indexid=131740 
/
INSERT INTO HtmlLabelIndex values(131740,'��ȫ���') 
/
delete from HtmlLabelIndex where id=131741 
/
delete from HtmlLabelInfo where indexid=131741 
/
INSERT INTO HtmlLabelIndex values(131741,'���д��б�') 
/
INSERT INTO HtmlLabelInfo VALUES(131741,'���д��б�',7) 
/
INSERT INTO HtmlLabelInfo VALUES(131741,'Sensitive Word List',8) 
/
INSERT INTO HtmlLabelInfo VALUES(131741,'�����~�б�',9) 
/
INSERT INTO HtmlLabelInfo VALUES(131740,'��ȫ���',7) 
/
INSERT INTO HtmlLabelInfo VALUES(131740,'Security Monitor',8) 
/
INSERT INTO HtmlLabelInfo VALUES(131740,'��ȫ�O��',9) 
/
delete from HtmlLabelIndex where id=131742 
/
delete from HtmlLabelInfo where indexid=131742 
/
INSERT INTO HtmlLabelIndex values(131742,'ϵͳ��ȫ') 
/
INSERT INTO HtmlLabelInfo VALUES(131742,'ϵͳ��ȫ',7) 
/
INSERT INTO HtmlLabelInfo VALUES(131742,'System Security',8) 
/
INSERT INTO HtmlLabelInfo VALUES(131742,'ϵ�y��ȫ',9) 
/
delete from HtmlLabelIndex where id=30089 
/
delete from HtmlLabelInfo where indexid=30089 
/
INSERT INTO HtmlLabelIndex values(30089,'���д�����') 
/
INSERT INTO HtmlLabelInfo VALUES(30089,'���д�����',7) 
/
INSERT INTO HtmlLabelInfo VALUES(30089,'Sensitive word set',8) 
/
INSERT INTO HtmlLabelInfo VALUES(30089,'�����~�O��',9) 
/
delete from HtmlLabelIndex where id=124780 
/
delete from HtmlLabelInfo where indexid=124780 
/
INSERT INTO HtmlLabelIndex values(124780,'������ʽ') 
/
INSERT INTO HtmlLabelInfo VALUES(124780,'������ʽ',7) 
/
INSERT INTO HtmlLabelInfo VALUES(124780,'Processing mode',8) 
/
INSERT INTO HtmlLabelInfo VALUES(124780,'̎����ʽ',9) 
/
delete from HtmlLabelIndex where id=26731 
/
delete from HtmlLabelInfo where indexid=26731 
/
INSERT INTO HtmlLabelIndex values(26731,'������Ա') 
/
INSERT INTO HtmlLabelInfo VALUES(26731,'������Ա',7) 
/
INSERT INTO HtmlLabelInfo VALUES(26731,'Remind staff',8) 
/
INSERT INTO HtmlLabelInfo VALUES(26731,'�����ˆT',9) 
/
delete from HtmlLabelIndex where id=19049 
/
delete from HtmlLabelInfo where indexid=19049 
/
INSERT INTO HtmlLabelIndex values(19049,'ģ��') 
/
INSERT INTO HtmlLabelInfo VALUES(19049,'ģ��',7) 
/
INSERT INTO HtmlLabelInfo VALUES(19049,'module',8) 
/
INSERT INTO HtmlLabelInfo VALUES(19049,'module',9) 
/
delete from HtmlLabelIndex where id=32165 
/
delete from HtmlLabelInfo where indexid=32165 
/
INSERT INTO HtmlLabelIndex values(32165,'�Ƿ���') 
/
INSERT INTO HtmlLabelInfo VALUES(32165,'�Ƿ���',7) 
/
INSERT INTO HtmlLabelInfo VALUES(32165,'whether or not open',8) 
/
INSERT INTO HtmlLabelInfo VALUES(32165,'�Ƿ��_��',9) 
/
delete from HtmlLabelIndex where id=33586 
/
delete from HtmlLabelInfo where indexid=33586 
/
INSERT INTO HtmlLabelIndex values(33586,'�ͻ���IP') 
/
INSERT INTO HtmlLabelInfo VALUES(33586,'�ͻ���IP',7) 
/
INSERT INTO HtmlLabelInfo VALUES(33586,'Client IP',8) 
/
INSERT INTO HtmlLabelInfo VALUES(33586,'�͑���IP',9) 
/