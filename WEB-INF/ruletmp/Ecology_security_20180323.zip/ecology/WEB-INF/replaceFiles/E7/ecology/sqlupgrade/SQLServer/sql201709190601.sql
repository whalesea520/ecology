delete from HtmlLabelIndex where id=131596 
GO
delete from HtmlLabelInfo where indexid=131596 
GO
INSERT INTO HtmlLabelIndex values(131596,'���д�') 
GO
INSERT INTO HtmlLabelInfo VALUES(131596,'���д�',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(131596,'Sensitive Word',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(131596,'���д�',9) 
GO
delete from HtmlLabelIndex where id=131598 
GO
delete from HtmlLabelInfo where indexid=131598 
GO
INSERT INTO HtmlLabelIndex values(131598,'���д�������־') 
GO
INSERT INTO HtmlLabelInfo VALUES(131598,'���д�������־',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(131598,'Sensitive Word Intercept Logs',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(131598,'�����~�r����־',9) 
GO
delete from HtmlLabelIndex where id=131636 
GO
delete from HtmlLabelInfo where indexid=131636 
GO
INSERT INTO HtmlLabelIndex values(131636,'ֱ�ӹ��˲��Ҽ�¼��־') 
GO
delete from HtmlLabelIndex where id=131637 
GO
delete from HtmlLabelInfo where indexid=131637 
GO
INSERT INTO HtmlLabelIndex values(131637,'����¼��־') 
GO
INSERT INTO HtmlLabelInfo VALUES(131637,'����¼��־',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(131637,'Only Record Log',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(131637,'�Hӛ���־',9) 
GO
INSERT INTO HtmlLabelInfo VALUES(131636,'ֱ�ӹ��˲��Ҽ�¼��־',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(131636,'Clean Sensitive Word And Record Log',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(131636,'ֱ���^�V����ӛ���־',9) 
GO
delete from HtmlLabelIndex where id=131740 
GO
delete from HtmlLabelInfo where indexid=131740 
GO
INSERT INTO HtmlLabelIndex values(131740,'��ȫ���') 
GO
delete from HtmlLabelIndex where id=131741 
GO
delete from HtmlLabelInfo where indexid=131741 
GO
INSERT INTO HtmlLabelIndex values(131741,'���д��б�') 
GO
INSERT INTO HtmlLabelInfo VALUES(131741,'���д��б�',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(131741,'Sensitive Word List',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(131741,'�����~�б�',9) 
GO
INSERT INTO HtmlLabelInfo VALUES(131740,'��ȫ���',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(131740,'Security Monitor',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(131740,'��ȫ�O��',9) 
GO
delete from HtmlLabelIndex where id=131742 
GO
delete from HtmlLabelInfo where indexid=131742 
GO
INSERT INTO HtmlLabelIndex values(131742,'ϵͳ��ȫ') 
GO
INSERT INTO HtmlLabelInfo VALUES(131742,'ϵͳ��ȫ',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(131742,'System Security',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(131742,'ϵ�y��ȫ',9) 
GO
delete from HtmlLabelIndex where id=30089 
GO
delete from HtmlLabelInfo where indexid=30089 
GO
INSERT INTO HtmlLabelIndex values(30089,'���д�����') 
GO
INSERT INTO HtmlLabelInfo VALUES(30089,'���д�����',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(30089,'Sensitive word set',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(30089,'�����~�O��',9) 
GO
delete from HtmlLabelIndex where id=124780 
GO
delete from HtmlLabelInfo where indexid=124780 
GO
INSERT INTO HtmlLabelIndex values(124780,'������ʽ') 
GO
INSERT INTO HtmlLabelInfo VALUES(124780,'������ʽ',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(124780,'Processing mode',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(124780,'̎����ʽ',9) 
GO
delete from HtmlLabelIndex where id=26731 
GO
delete from HtmlLabelInfo where indexid=26731 
GO
INSERT INTO HtmlLabelIndex values(26731,'������Ա') 
GO
INSERT INTO HtmlLabelInfo VALUES(26731,'������Ա',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(26731,'Remind staff',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(26731,'�����ˆT',9) 
GO
delete from HtmlLabelIndex where id=19049 
GO
delete from HtmlLabelInfo where indexid=19049 
GO
INSERT INTO HtmlLabelIndex values(19049,'ģ��') 
GO
INSERT INTO HtmlLabelInfo VALUES(19049,'ģ��',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(19049,'module',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(19049,'module',9) 
GO
delete from HtmlLabelIndex where id=32165 
GO
delete from HtmlLabelInfo where indexid=32165 
GO
INSERT INTO HtmlLabelIndex values(32165,'�Ƿ���') 
GO
INSERT INTO HtmlLabelInfo VALUES(32165,'�Ƿ���',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(32165,'whether or not open',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(32165,'�Ƿ��_��',9) 
GO
delete from HtmlLabelIndex where id=33586 
GO
delete from HtmlLabelInfo where indexid=33586 
GO
INSERT INTO HtmlLabelIndex values(33586,'�ͻ���IP') 
GO
INSERT INTO HtmlLabelInfo VALUES(33586,'�ͻ���IP',7) 
GO
INSERT INTO HtmlLabelInfo VALUES(33586,'Client IP',8) 
GO
INSERT INTO HtmlLabelInfo VALUES(33586,'�͑���IP',9) 
GO